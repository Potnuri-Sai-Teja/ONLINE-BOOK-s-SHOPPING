<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");

$title=$_SESSION['book'];
$author=$_POST['aun'];
$publisher=$_POST['pbn'];
$t;
			$a;
			$p;
			$i;
			$c;
	$co;
if($title && $author && $publisher )
{
		$query= mysql_query("SELECT * FROM book_info_table WHERE book_name='$title' AND  author_name='$author' AND publisher_name='$publisher' ")or die("coudld connect to database 3");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_array($query))
		{
			$t= $row['book_name'];
			$a=$row['author_name'];
			$p=$row['publisher_name'];
			$i=$row['img_path'];
			$c=$row['book_cost'];
			$co=$row['course'];

                     	}
	}
}
else
   {
    echo "<script>
        window.location.href='search1233.html';
            alert('Please Enter Details');
</script> ";
 }  
$_SESSION['imgp']=$i;
	
	$_SESSION['aname']=$a;
	$_SESSION['pname']=$p;
	$_SESSION['name']=$t;
	$_SESSION['cou']=$co;
$_SESSION['amount']=$c;	
		if($t==$title && $a==$author && $p==$publisher)
		{
		
			echo "<script>
		    window.location.href='book_imgg.php';</script>";
      			header("location:book_imgg.php");
		
		}

	 else if($title==$t && $author!=$a && $publisher!=$p)
	{
	 ?> <script>
    window.location.href="exe3.php";
            alert("unaccessble author name and publisher ");
            document.password.value.focus();
            </script> 
<?php 
	}

	 else if($title==$t && $author==$a && $publisher!=$p)
	{
		?>  <script>
    window.location.href="exe3.php";
            alert("unaccessble publisher name ");
            document.password.value.focus();
            </script>  <?php
	}

	else 
	{
?>
        <script>
    window.location.href="search1233.html";
    alert("please enter details");
    </script> <?php
	}

	 

?>
</body>
</html>