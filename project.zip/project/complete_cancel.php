<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
 
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");

session_start();
$name=$_SESSION['name'];


$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$f="processing";

$sai=$_SESSION['booking_code'];
	$query= mysql_query("SELECT *  FROM user_delivery WHERE  user_name='$name'  AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f'")or die("not selected");
	

	
?>
<table width="100%" border="0">
								<tr>
									<Td> <b>name</td>
									<Td> <b>id</td>
									<td> <b>book name</td>
									<td>  <b>author name</td>
									<td> <b>Publisher_nam</td>
									<td> <b>Total books</td>
									<td> <b>Amount</td>
									<td> <b>Total Amount</td>
									<td> <b>Total cost</td>
									<td>  <b> booking date</td>
									<td>  <b> Delivery date</td>
									<td>  <b> address</td>
									<td>  <b> phone_number</td>
									<td>  <b> email id</td>
									<td>  <b> Delivery report</td>



									



								
								</tr>
								<tr><td colspan="20"><hr style="border:2px Solid #a1a1a1;"></tr>
								
							<?php 
		

$dbname='user_name';
$dbid='id';
$dbbna='book_na';
$dbana='author_na';
$dbpba='publisher_na';
$dbtob='total_books';
$dbcost='cost';
$dbtcost='book_total_cost';
$dbdate='datee';
$dbddate='delivery_date';
$dbadd='address';
$dbeid='email_add';
$dbpn='phone_number';
$dbtoc='total_cost';
$dbdr='delivery_report';

	$c=1;

while($rows = mysql_fetch_array($query))
		{
	        
$id=$rows[$dbid];
echo "
 		   <br>
  		  <tr> 

	<td> $rows[$dbname] <br>  </td>
	<td> $c  <br></td>
	<td> $rows[$dbbna]   <br></td>
	<td> $rows[$dbana]   <br></td>
	<td> $rows[$dbpba]   <br></td>
	<td> $rows[$dbtob]   <br></td>
	<td> $rows[$dbcost]  <br></td><td> $rows[$dbtoc]  <br></td>
<td> $rows[$dbtcost]  <br></td>
<td> $rows[$dbdate]  <br></td>
<td> $rows[$dbddate]  <br></td>
<td> $rows[$dbadd]  <br></td>
<td> $rows[$dbeid]  <br></td>
<td> $rows[$dbpn]  <br></td>
<td> $rows[$dbdr]  <br></td>

	
";
                
$c++;
}

?>	
 </table>   						
<br><br> <br><center>	<font size="06">
<font size="5" color="darkblack"> Message :<br></font> <br>
<font size="5" color="red"> Cancelation Sucessfully Completed Click On Ok Button </font><br>
<br><br>




<form action="book_choices.html">
<input type="submit" value="Ok"> 
</form>

<form action="homepage.html">
<input type="submit" value="Homepage"> 
</form>

</font></center>

</body>
</html> 