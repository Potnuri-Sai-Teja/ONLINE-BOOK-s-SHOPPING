<?php
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
//mysql_query("create database owner") ;
echo"database created ";
mysql_select_db("owner") or die("not selected");
mysql_query("CREATE TABLE owner_data(user_name varchar(15),password varchar(20),store_name varchar(25),PRIMARY KEY(store_name))") or die(" nttootot");
mysql_query("CREATE TABLE Delivery_boy_data(user_name varchar(15),password varchar(20),store_name varchar(25),PRIMARY KEY(store_name))") or die(" nttootot");

?>
