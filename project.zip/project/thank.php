<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	
		<div id="logo">
	<center>		<h1 color="green">ONLINE BUS PASS BOOKING</h1><center>
		</div>
		
	
<br><br><br>
 </font><br><br><br>
<font size="5" color="darkblack"> Message :<br></font> <br>
<font size="5" color="red"> Your Booking Is  Suceessfully Completed.  please Remember booking ID</font><br>
<br><br>

<font size="6"> Thank You For APPLYING Online BUS PASS :</font> <font size="5" color="blue"> <i>SAI TEJA POTNURI </i></font> <br>  
<br><br>
<font size="6"> YOUR Booking ID :</font> <font size="5" color="blue"> MDP-ID6976412 </i></font> <br>


<br><br>
<form action="homepage.html">
<input type="submit" value="Ok"> 
</form><br>

</font></center>

</body>
</html> 