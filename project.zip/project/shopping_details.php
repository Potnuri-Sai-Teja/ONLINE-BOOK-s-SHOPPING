<?php 
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
mysql_query("create database shop");
mysql_select_db("shop")or die("nottttt");
mysql_query("create table user_shopping(id bigint(4) AUTO_INCREMENT UNIQUE,first_name varchar(25),address varchar(100),postal_code int(25),city varchar(40),state varchar(40),phone bigint(17),email varchar(50))");
echo "table created";

$a=$_POST['fn'];
$c=$_POST['add'];
$d=$_POST['pc'];
$e=$_POST['ci'];
$f=$_POST['st'];
$g=$_POST['mbn'];
$h=$_POST['email'];

$_SESSION['user_na']=$a;
$_SESSION['address']=$c;
$_SESSION['city_na']=$e;
$_SESSION['state_na']=$f;
$_SESSION['mobile']=$g;
$_SESSION['email_add']=$h;
if($a==NULL || $c==NULL || $d==0 || $e==NULL || $f==NULL || $g==0 || $h==NULL )
{ ?>
<script>
    
            alert("Enter your details ");
           window.location.href="shopping_details.html";
            </script>
<?php
}
else 
{

	
 mysql_query("INSERT INTO user_shopping VALUES(null,'$a','$c',$d,'$e','$f',$g,'$h')") or die("120120");
echo " row is inserted";
$query= mysql_query("SELECT * FROM user_shopping WHERE first_name='$a' ")or die("coudld connect to database 3");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_array($query))
		{
			
			$coo=$row['first_name'];

                     	}
	}


$_SESSION['user_name']=$coo;
header("location:payment.html");	

	
}

?>
