<?php
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
mysql_query("create database user_book");
mysql_select_db("info_book") or die("nottttt");
mysql_query("create table books_selected(id int(4) AUTO_INCREMENT UNIQUE,book varchar(50),author varchar(50),publisher varchar(50),type varchar(50),cost int(13),total_books int(10),total_cost int(10)");
echo "table created";
mysql_query("ALTER TABLE `books_selected` ADD `id` INT(4) NOT NULL AUTO_INCREMENT FIRST, ADD UNIQUE (`id`)");
session_start();
	
	$Author=$_SESSION['aname'];
	$Publisher=$_SESSION['pname'];
	$Name=$_SESSION['name'];
	$Course=$_SESSION['cou'];
	$Cost=$_SESSION['amount'];
$total_amount=$_SESSION['totala'];
$num_of_books=$_SESSION['selected'];

mysql_query("insert into books_selected values(null,'$Name','$Author','$Publisher','$Course',$Cost,$num_of_books,$total_amount)") or die("not inserted");
echo "row is inserted";
header("location:2.php");





?>
