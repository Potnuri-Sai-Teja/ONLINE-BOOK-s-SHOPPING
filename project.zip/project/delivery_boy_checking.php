<?php
session_start();
$uid = $_POST['dbn'];
$password =$_POST['dbp'];
if($uid&&$password)
{
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("owner") or die ("couldn't find database");
	$query= mysql_query("SELECT * FROM delivery_boy_data WHERE user_name='$uid' ");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$dbuid= $row['user_name'];
			$dbpassword=$row['password'];
		}
		if($uid==$dbuid && $password==$dbpassword)
		{
            $_SESSION['anm']=$uid;
			?><script>
    window.location.href="user_delivery.html";

                </script><?php

			
		}
	 else if($uid==$dbuid && $password!=$dbpassword)
		 ?><script>
    window.location.href="OWNERLOGIN.HTML";
            alert("You Entered InCorrect Password ");
            document.password.value.focus();
            </script><?php 
	}
	else 
        ?><script>
    window.location.href="OWNERLOGIN.HTML";
    alert("User Doesnt Exist");
    </script>
<?php

	
}
else
    ?>
    <script>
        window.location.href="OWNERLOGIN.HTML";
            alert("Please Enter Username and Password");
</script><?php
    
	
?>