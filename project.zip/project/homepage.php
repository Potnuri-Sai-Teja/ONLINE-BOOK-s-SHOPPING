 <?php 
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");
mysql_select_db("info_book") or die("couldn't find database 1");
$na=$_SESSION['name'];
$an=$_SESSION['aname'];
$pn=$_SESSION['pname'];
$dbbb=array("");
$dbbk=array("");
$dbna=array("");
			$dban=array("");
			$dbpn=array("");

$aa='total_books';
$bb='book';
$cc='author';
$dd='publisher';
$ee='num_books';
$query1="";
$query="";
$totb="";
$c=1;
$query2= mysql_query("SELECT * FROM books_selected");

$i=0;





$query= mysql_query("SELECT * FROM books_selected") or die("soooooooo") ;

	
		while($rows=mysql_fetch_array($query))
		{

			$dbbb[$i]=$rows[$aa];
			$dbna[$i]=$rows[$bb];
			$dban[$i]=$rows[$cc];
			$dbpn[$i]=$rows[$dd];
			$i++;
		}

for($i=0;$i<=sizeof($dbbb);$i++)
{
$query1= mysql_query("SELECT * FROM book_info_table WHERE book_name='$dbna[$i]' AND author_name='$dban[$i]' ") or die("kkkkkkkkk") ;
		while($row=mysql_fetch_array($query1))
		{
			$dbbk[$i]=$row[$ee];
			
		}

}

for($i=0;$i<=sizeof($dbbb);$i++)
{
$totb[$i]=$dbbk[$i] - $dbbb[$i];
mysql_query("UPDATE book_info_table SET num_books='$totb[$i]' WHERE book_name='$dbna[$i]' AND author_name='$dban[$i]' AND publisher_name='$dbpn[$i]'") or die("not updated");
 echo "updated";
}

header("location:delivery.php");



?>