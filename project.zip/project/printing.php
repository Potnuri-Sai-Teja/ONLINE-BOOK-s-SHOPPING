<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
 
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
	$query= mysql_query("SELECT * FROM books_selected")or die("not selected");
	

	
?>
<table width="100%" border="0">
								<tr>
									<Td> <b>S.no
									<Td> <b>Book_name
									<td> <b>Author_name
									<td> <b>Publisher_name
									<td> <b>Group
									<td> <b>Amount
									<td> <b>Total books
									<td> <b>Total Amount
									<td> <b>Select
								</tr>
								<tr><td colspan="9"><hr style="border:1px Solid #a1a1a1;"></tr>
							<?php 
		
session_start();
$dbname='book';
$dbauthor='author';
$dbpublisher='publisher';
$dbcourse='type';
$dbcost='cost';
$dbtob='total_books';
$dbtoc='total_cost';
	$c=1;
echo '<form method="post" action="del.php">';
while($rows = mysql_fetch_array($query))
		{
	        
$id=$rows['id'];
echo "
 		   <br>
  		  <tr> 
	<td>$c</td>
	<td> $rows[$dbname] <br>  </td>
	<td> $rows[$dbauthor]   <br></td>
	<td> $rows[$dbpublisher]   <br></td>
	<td> $rows[$dbcourse]   <br></td>
	<td> $rows[$dbcost]   <br></td>
	<td> $rows[$dbtob]   <br></td>
	<td> $rows[$dbtoc]  <br></td>
                <td>";echo "<input type='checkbox' name='ch[]' value='$id' >Delete</td> </tr>";
$c++;
$_SESSION['book_name']=$rows[$dbname];	
		$_SESSION['author_name']=$rows[$dbauthor] ;
		$_SESSION['publisher_name']=$rows[$dbpublisher] ;
$_SESSION['num']=$rows[$dbtob] ;
               
	}

?> <?php

		echo '</table><br><br><center><input type="submit" value="submit"></form>';			
$z=$_SESSION['total'];						
										
								
							 ?>
    						
<br><br> <br><center><font size="06">	
<form name="calculate" action="total_caluculate.php">
<input type="submit" value="Calculate total cost">
<font size="06">Total amount : <?php echo $z; ?> </font>
</form>
<br>
<form action="shopping_details.html">
<input type="submit" value="CONTINUE"><br> 
</form><br>
<form action="2.php">
<input type="submit" value="Go Back"> 
</form>


</font></center>

</body>
</html> 