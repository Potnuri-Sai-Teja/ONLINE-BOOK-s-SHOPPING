<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php 
session_start();

$num_book=$_POST['enb'];

	$author=$_SESSION['aname'];
	$publisher=$_SESSION['pname'];
	$name=$_SESSION['name'];
	$total;
		
if($num_book)
{
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
	$query= mysql_query("SELECT * FROM book_info_table WHERE book_name='$name' AND  author_name='$author' AND publisher_name='$publisher' ")or die("coudld connect to database 3");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_array($query))
		{
			$q=$row['num_books'];
			$c=$row['book_cost'];			

               	}
		
	}

}
else
   { ?>
  <script>
       window.location.href="book_imgg.php";
            alert("Please Enter Details");
	
</script> 
<?php
 } 


if($num_book!=0)

{
 
	if($q>$num_book)
	{
		$total=$num_book * $c;
		$_SESSION['totala']=$total;
		$_SESSION['selected']=$num_book;
		echo "<script>
    		window.location.href='1.php';
		</script> "; 

	}
else
{
		 echo "<script>
           alert('books out of range');
window.location.href='book_imgg.php';
            </script> "; 
}
} 
else
{
		 echo "<script>
           alert('books out of stock');
window.location.href='book_imgg.php';
            </script> "; 
}

?>
</body>
</html>