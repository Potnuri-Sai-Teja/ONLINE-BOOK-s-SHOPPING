-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2018 at 06:36 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `info_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `books_selected`
--

CREATE TABLE `books_selected` (
  `id` int(4) NOT NULL,
  `book` varchar(50) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `publisher` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `cost` int(13) DEFAULT NULL,
  `total_books` int(10) DEFAULT NULL,
  `total_cost` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `book_info_table`
--

CREATE TABLE `book_info_table` (
  `id` int(4) NOT NULL,
  `book_name` varchar(100) DEFAULT NULL,
  `author_name` varchar(30) DEFAULT NULL,
  `publisher_name` varchar(30) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `img_path` varchar(100) DEFAULT NULL,
  `book_cost` int(13) DEFAULT NULL,
  `num_books` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_info_table`
--

INSERT INTO `book_info_table` (`id`, `book_name`, `author_name`, `publisher_name`, `course`, `img_path`, `book_cost`, `num_books`) VALUES
(1, 'computer networks', 'depak guptha', 'falcon', 'computers', 'cns', 55, 23),
(2, 'digital and computer design', 'm.morris mano', 'FALCON', 'computers', 'dcd', 150, 55),
(3, 'namaste', 'mi', 'mi1', 'kkm', 'books.jpg', 20, 158),
(4, 'hiii', 'hello', 'namste', 'cse', 'Harsha .jpg', 40, 111),
(5, 'Love', 'Teja', 'muneer', 'Personal', 'Harsha.jpg', 100, 100);

-- --------------------------------------------------------

--
-- Table structure for table `book_search`
--

CREATE TABLE `book_search` (
  `book_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_search`
--

INSERT INTO `book_search` (`book_name`) VALUES
('digital and computer design'),
('namaste'),
('computer networks'),
('digital and computer design'),
('digital and computer design'),
('hiii'),
('computer networks'),
('hiii'),
('namaste'),
('hiii'),
('Love');

-- --------------------------------------------------------

--
-- Table structure for table `user_delivery`
--

CREATE TABLE `user_delivery` (
  `user_name` varchar(50) DEFAULT NULL,
  `booking_id` bigint(100) DEFAULT NULL,
  `id` int(4) NOT NULL,
  `book_na` varchar(50) DEFAULT NULL,
  `author_na` varchar(50) DEFAULT NULL,
  `publisher_na` varchar(50) DEFAULT NULL,
  `total_books` int(100) DEFAULT NULL,
  `cost` int(13) DEFAULT NULL,
  `book_total_cost` int(13) DEFAULT NULL,
  `total_cost` int(10) DEFAULT NULL,
  `datee` varchar(50) DEFAULT NULL,
  `delivery_date` varchar(50) DEFAULT NULL,
  `delivery_report` varchar(15) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `email_add` varchar(75) DEFAULT NULL,
  `phone_number` bigint(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_delivery`
--

INSERT INTO `user_delivery` (`user_name`, `booking_id`, `id`, `book_na`, `author_na`, `publisher_na`, `total_books`, `cost`, `book_total_cost`, `total_cost`, `datee`, `delivery_date`, `delivery_report`, `city`, `state`, `address`, `email_add`, `phone_number`) VALUES
('setty', 1, 2, 'computer networks', 'depak guptha', 'falcon', 5, 55, 275, 275, '2018-03-16', '2018-03-19', 'Delivered', 'visakhapatnam', 'ap', 'hvhvnbvmbnmv', 'kjbkvkmvnbv', 9666435575),
('Sridhar', 2, 3, 'digital and computer design', 'm.morris mano', 'FALCON', 5, 150, 750, 1190, '2018-09-09', '2018-09-12', 'processing', 'Srikakulam', 'Andhrapradesh', 'Srikakulam', 'aaaaaaaa', 123456789),
('Sridhar', 2, 5, 'hiii', 'hello', 'namste', 10, 40, 400, 1190, '2018-09-09', '2018-09-12', 'processing', 'Srikakulam', 'Andhrapradesh', 'Srikakulam', 'aaaaaaaa', 123456789),
('Sridhar', 2, 6, 'namaste', 'mi', 'mi1', 2, 20, 40, 1190, '2018-09-09', '2018-09-12', 'processing', 'Srikakulam', 'Andhrapradesh', 'Srikakulam', 'aaaaaaaa', 123456789);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books_selected`
--
ALTER TABLE `books_selected`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `book_info_table`
--
ALTER TABLE `book_info_table`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `user_delivery`
--
ALTER TABLE `user_delivery`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books_selected`
--
ALTER TABLE `books_selected`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `book_info_table`
--
ALTER TABLE `book_info_table`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_delivery`
--
ALTER TABLE `user_delivery`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
