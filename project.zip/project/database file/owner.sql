-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2018 at 06:38 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `owner`
--

-- --------------------------------------------------------

--
-- Table structure for table `delivery_boy_data`
--

CREATE TABLE `delivery_boy_data` (
  `user_name` varchar(15) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `store_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_boy_data`
--

INSERT INTO `delivery_boy_data` (`user_name`, `password`, `store_name`) VALUES
('teja', '183', 'rajeswari');

-- --------------------------------------------------------

--
-- Table structure for table `owner_data`
--

CREATE TABLE `owner_data` (
  `user_name` varchar(15) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `store_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `owner_data`
--

INSERT INTO `owner_data` (`user_name`, `password`, `store_name`) VALUES
('teja', '1233', 'rajeswari'),
('vineeth', 'vinu14', 'rajeswari1'),
('pravalika', 'pravallika', 'rajeswari3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `delivery_boy_data`
--
ALTER TABLE `delivery_boy_data`
  ADD PRIMARY KEY (`store_name`);

--
-- Indexes for table `owner_data`
--
ALTER TABLE `owner_data`
  ADD PRIMARY KEY (`store_name`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
