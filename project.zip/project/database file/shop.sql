-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2018 at 06:40 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_shopping`
--

CREATE TABLE `user_shopping` (
  `id` bigint(4) NOT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `postal_code` int(25) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `state` varchar(40) DEFAULT NULL,
  `phone` bigint(17) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_shopping`
--

INSERT INTO `user_shopping` (`id`, `first_name`, `address`, `postal_code`, `city`, `state`, `phone`, `email`) VALUES
(1, 'setty', 'hvhvnbvmbnmv', 530004, 'visakhapatnam', 'ap', 9666435575, 'kjbkvkmvnbv'),
(2, 'Sridhar', 'Srikakulam', 530005, 'Srikakulam', 'Andhrapradesh', 123456789, 'aaaaaaaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_shopping`
--
ALTER TABLE `user_shopping`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_shopping`
--
ALTER TABLE `user_shopping`
  MODIFY `id` bigint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
