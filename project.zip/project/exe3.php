<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<form method="post" action="exe1.php">
 <br>
<center>
<font face="Lucida Handwriting" color="green" size="08"> Searching Books </font><br><br>
<br><br>
<label for="lnm"><font face="Segoe Script" size="5">Book name : <?php 	session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");
$bn=$_SESSION['book'];
echo $bn;
?>
  &nbsp;&nbsp;&nbsp;</label>
<br><br>
<label for="lnm"><font face="Segoe Script" size="5">Search by Author Name &nbsp;&nbsp;&nbsp;</label>
<select name="aun">
<option> select </option>

 <?php 
	session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");
$bn=$_SESSION['book'];
$sam='author_name';
$dbsam=array("");
$i=0;
$f=sizeof($dbsam);
$query="";
$query=mysql_query("select author_name from book_info_table  WHERE book_name='$bn'");
while($rows=mysql_fetch_array($query))
		{
		
			$dbsam[$i]=$rows[$sam];				
			$i++;
		}
for($i=0;$i<=$f;$i++)
{
		echo " <option> $dbsam[$i] </option>";
}
?>

</select>
<br><br>
<label for="lnm"><font face="Segoe Script" size="5">Search by Publisher Name &nbsp;&nbsp;&nbsp;</label>
<select name="pbn">
<option>  select  </option>
 <?php 
	session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");
$bn=$_SESSION['book'];
$sam='publisher_name';
$dbsam=array("");
$i=0;
$f=sizeof($dbsam);
$query="";
$query=mysql_query("select publisher_name from book_info_table  WHERE book_name='$bn'");
while($rows=mysql_fetch_array($query))
		{
		
			$dbsam[$i]=$rows[$sam];				
			$i++;
		}
for($i=0;$i<=$f;$i++)
{
	echo " <option> $dbsam[$i] </option>";
}
?>



</select>

<br><br>
<input class="btn" type="submit" value="submit">
</form>

<form action="search1233.html">
<input type="submit" value="Back">
</form>

</b></font>
</center>

</body>
</html>