<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php

	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
session_start();
$name=$_SESSION['name'];
$booking_dates=$_SESSION['booking_date'];
$delivered_dates=$_SESSION['delivered_date'];
$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$f="processing";



	$query= mysql_query("SELECT *  FROM user_delivery WHERE  user_name='$name' AND datee='$booking_dates' AND delivery_date='$delivered_dates' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f'")or die("not selected");

	

$total=0;	


$dbtoc='book_total_cost';
	

while($rows = mysql_fetch_array($query))
		{
	       $total=$total+ $rows[$dbtoc] ; 
		}
$_SESSION['totals']=$total;
	header("location:books_delete.php");


?>
</body>
</html>
		
   

 				
						
										
								
							