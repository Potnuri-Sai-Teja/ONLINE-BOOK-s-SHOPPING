<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");
mysql_query("create table book_search(book_name varchar(100))");
echo "table created";
$a=$_POST['tt'];
$_SESSION['book']=$a;
mysql_query("INSERT INTO book_search VALUES('$a')") or die("120120");
echo "inserted";



		$query= mysql_query("SELECT * FROM book_info_table WHERE book_name='$a' ")or die("coudld connect to database 3");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_array($query))
		{
			$t= $row['book_name'];
		}	

       	}

if($a!=NULL)
{
if($a==$t)
{
	
	header("location:exe3.php");

}

else
{  ?>
<script>
        window.location.href='search1233.html';
            alert("Your Book is not existed Please retry");
</script> 
<?php
}
}
else
{  ?>
<script>
        window.location.href='search1233.html';
            alert("plz Enter book name");
</script> 
<?php
}
?>
</body>
</html>