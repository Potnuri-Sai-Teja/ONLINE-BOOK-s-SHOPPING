
<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>




<?php
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");
mysql_select_db("info_book") or die("nottttt");
$name=null;
$phone_nuns=0;
$Email_ids=null;
$f=null;
$db=0;
$dbtb=0;
$cost=0;
$dbbook=null;

$dban=null;


$dbpn=null;
















$name=$_SESSION['name'];
$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$sai=$_SESSION['booking_code'];

$f="processing";
$db=$_POST['bb1'];
$dbtb=$_SESSION['to'];
$cost=$_SESSION['cos'];
$dbbook=$_SESSION['bb'];

$dban=$_SESSION['au'];


$dbpn=$_SESSION['pu'];
$boe=$_POST['bb1'];
if($db!=NULL)
{

	$query= mysql_query("SELECT *  FROM user_delivery WHERE publisher_na='$dbpn' AND user_name='$name' AND book_na='$dbbook' AND author_na='$dban' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f'")or die("not selected");


$query123= mysql_query("SELECT num_books FROM book_info_table WHERE book_name='$dbbook' AND author_name='$dban' AND publisher_name='$dbpn' ") ;
		while($row=mysql_fetch_assoc($query123))
		{
			$dbavb= $row['num_books'];
		
                }
	
		




	
echo $dbtb."<br>";
	$dbtotal_books=$dbtb - $db;
$dbtotal_bookes=$dbavb + $db;
	
mysql_query("UPDATE user_delivery SET total_books='$dbtotal_books' WHERE publisher_na='$dbpn' AND user_name='$name' AND book_na='$dbbook' AND author_na='$dban' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f' ") or die("not updated");
mysql_query("UPDATE book_info_table SET num_books='$dbtotal_bookes' WHERE book_name='$dbbook' AND author_name='$dban' AND publisher_name='$dbpn' ") or die("not updated");

$total_costs;
$total_costs=$dbtotal_books * $cost;
echo $total_costs.$cost.$dbtotal_books;
mysql_query("UPDATE user_delivery SET book_total_cost='$total_costs' WHERE publisher_na='$dbpn' AND user_name='$name' AND book_na='$dbbook' AND author_na='$dban' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f' ") or die("not updated");

	$query= mysql_query("SELECT *  FROM user_delivery WHERE  user_name='$name' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f'")or die("not selected");

	$query1= mysql_query("SELECT *  FROM user_delivery WHERE publisher_na='$dbpn' AND user_name='$name' AND book_na='$dbbook' AND author_na='$dban' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f'")or die("not selected");


$total=0;	
$dbtotal='book_total_cost';


	
while($rows = mysql_fetch_array($query))
		{
	       $total=$total+$rows[$dbtotal]; 
		
		}


mysql_query("UPDATE user_delivery SET total_cost='$total' WHERE user_name='$name' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f' ") or die("not updated");
header("location:complete_cancel.php");

}
else
{
?>
<script>
alert("please enter value");
window.location.href="can2.php";
</script>
<?php
}


?>
</body>
</html>
