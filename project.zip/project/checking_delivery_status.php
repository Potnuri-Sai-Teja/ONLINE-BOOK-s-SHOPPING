<?php
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
mysql_select_db("info_book") or die("nottttt");

$name=$_POST['udn'];
$booking_code=$_POST['ubd'];
 
$phone_nun=$_POST['uph'];
$Email_id=$_POST['uei'];


$query= mysql_query("SELECT *  FROM user_delivery WHERE  user_name='$name' AND booking_id='$booking_code' AND phone_number='$phone_nun' AND email_add='$Email_id' ") or die ("Select eruygfuyhda");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$dbname= $row['user_name'];
			$dbdates= $row['booking_id'];
			$dbphn= $row['phone_number'];	
			$dbea= $row['email_add'];
	
			                      		
		}
	}


if($name==NULL || $booking_code==-1 || $phone_nun==0 || $Email_id==NULL)
{
?>
<script>
alert("please enter all values");
window.location.href="user_delivery.html";
</script>
<?php
}
else
{
if($name==$dbname && $booking_code==$dbdates && $phone_nun==$dbphn && $Email_id==$dbea)
{
$ee="Delivered";
mysql_query("UPDATE user_delivery SET delivery_report='$ee' WHERE  user_name='$name' AND booking_id='$booking_code' AND phone_number='$phone_nun' AND email_add='$Email_id'") or die("not updated");
header("location:homepage.html");
}
else
{
?>
<script>
alert("Data is not matched please check and re-enter ");
window.location.href="user_delivery.html";
</script>
<?php

}
	
}
?>