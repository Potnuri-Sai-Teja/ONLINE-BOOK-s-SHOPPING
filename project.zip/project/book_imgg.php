<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenus.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
 session_start();
	$path=$_SESSION['imgp'];
	$Author=$_SESSION['aname'];
	$Publisher=$_SESSION['pname'];
	$Name=$_SESSION['name'];
	$Course=$_SESSION['cou'];
	$Cost=$_SESSION['amount'];
	echo $path;		
?>

<center><img src="book_images\<?php echo $path;?>"  width="450" height="350" alt="noimage" ><br>
<font size="04" >Book_name      : <?php echo $Name;?> </font><br>
<font size="04" >Author_name    : <?php echo $Author;?> </font><br>
<font size="04" >Publisher_name : <?php echo $Publisher;?> </font><br>
<font size="04" >Group          : <?php echo $Course;?> </font><br>
<font size="04" >Amount         : <?php echo $Cost;?> </font><br> 
<font size="04" >Available books        : <?php 
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");
	$query= mysql_query("SELECT num_books FROM book_info_table WHERE book_name='$Name' AND author_name='$Author' AND publisher_name='$Publisher' ") ;
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$dbavb= $row['num_books'];
		
                }
	
	}

echo $dbavb;
?> </font><br>
<form method="post" action="checking.php">
<font size="05" color="green">Enter number of books : <input type="text" name="enb"> </font><br>
<input type="submit" value="Add to List">
</form>


<form action="exe3.php">
<input type="submit" value="Back">
</form>
</center>
</body>
</html> 