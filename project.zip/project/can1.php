<html>
<head>
<title>Shopping</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<form method="post" action="can2.php">
 <center> <font face="Lucida calligraphy" color="blue" size="7"> cancelation book   </font> </center> <br>
<center>
 <label for="nm"><font face="Segoe Script" size+4><b>Book name &nbsp;&nbsp;&nbsp;&nbsp</label></font>

<select name="bb">
<option> select </option>

 <?php 
	session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");

$sam='book_na';
$dbsam=array("");
$i=0;
$f=sizeof($dbsam);
$query="";
$name=$_SESSION['name'];
$sai=$_SESSION['booking_code'];
$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$e="processing";

echo $name."<br>".$booking_dates."<br>".$delivered_dates."<br>".$phone_nuns."<br>".$Email_ids."<br>".$e;
$query="";
$query=mysql_query("select book_na from user_delivery  WHERE  user_name='$name' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$e' ");
while($rows=mysql_fetch_array($query))
		{
		
			$dbsam[$i]=$rows[$sam];				
			$i++;
		}
for($i=0;$i<=$f;$i++)
{
		echo " <option> $dbsam[$i] </option>.<br>";
}
?>
</select>
<br><br>


<label for="nm"><font face="Segoe Script" size+4><b>author name &nbsp;&nbsp;&nbsp;&nbsp</label></font>
<select name="cc">

<option>select</option>

 <?php 

$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");

$sam='author_na';
$dbsam=array("");
$i=0;
$f=sizeof($dbsam);
$query="";
$name=$_SESSION['name'];
$sai=$_SESSION['booking_code'];
$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$e="processing";
$a123=$_SESSION['ab1'];

$b123=$_SESSION['ab2'];

$c123=$_SESSION['ab3'];


$query1="";
$query1=mysql_query("select author_na from user_delivery  WHERE  user_name='$name' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$e' ");
while($rows=mysql_fetch_array($query1))
		{
		
			$dbsam[$i]=$rows[$sam];				
			$i++;
		}





for($i=0;$i<=$f;$i++)
{
		
		echo " <option> $dbsam[$i] </option>";
		}
?>

</select>
<br><br>



<label for="nm"><font face="Segoe Script" size+4><b>Publisher name &nbsp;&nbsp;&nbsp;&nbsp</label></font>

<select name="dd">
<option> select </option>

 <?php 

$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");

$sam='publisher_na';
$dbsam=array("");
$i=0;
$f=sizeof($dbsam);
$query="";
$name=$_SESSION['name'];
$sai=$_SESSION['booking_code'];
$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$e="processing";

$query2="";
$query2=mysql_query("select publisher_na from user_delivery  WHERE  user_name='$name' AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$e' ");
while($rows=mysql_fetch_array($query2))
		{
		
			$dbsam[$i]=$rows[$sam];				
			$i++;
		}
echo $f;
for($i=0;$i<=$f;$i++)
{
		echo " <option> $dbsam[$i] </option>";
}
?>
</select>
<br><br>



<input class="btn" type="submit" value="Go"><br>
 </form>

<form action="book_choices.html">
<input type="submit" value="Back">
</form>

</b></font>
</center>

</body>
</html>




