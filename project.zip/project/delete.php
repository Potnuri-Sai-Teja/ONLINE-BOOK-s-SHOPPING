<?php

session_start();
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
$a;

$Id=implode(',',$_POST['ch']);
$a=$_SESSION['book_name'];
$b=$_SESSION['author_name'] ;
$c=$_SESSION['publisher_name'];
$d=$_SESSION['num'];

mysql_query("delete from user_delivery where id in($Id) ")or die("cant delete");

/*
echo $Id;

$q1=array(10);
$q1=explode(',',$Id);
print_r($q1);



mysql_query("UPDATE book_info_table SET num_books='num' WHERE book_name='$a' AND author_name='$b' AND publisher_name='$c'") or die("not updated");
*/
header("location:books_delete.php");

	
?>
	