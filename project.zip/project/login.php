<?php
session_start();

$uid=$_POST['unm'];
$password=$_POST['upw'];
if($uid&&$password)
{
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("users") or die("couldn't find database");
	$query= mysql_query("SELECT user_name,password FROM user_information WHERE user_name='$uid' ") ;
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$dbuid= $row['user_name'];
			$dbpassword=$row['password'];
                     		}
		if($uid==$dbuid && $password==$dbpassword)
		{
       
			?><script>
    window.location.href="choice.html";

                </script><?php

			
		}
	 else if($uid==$dbuid && $password!=$dbpassword)
		 ?><script>
   
            alert("you entered incoorect password");
 window.location.href="cust_login.html";
            document.password.value.focus();
            </script><?php 
	}
	else 
        ?><script>
  
    alert("User Doesnt Exist");
  window.location.href="cust_login.html";
    </script>
<?php

	
}
else
    ?>
    <script>
        window.location.href="cust_login.html";
            alert("Please Enter Username and Password");
</script><?php
    
	
?>