
<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>




<?php
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");

mysql_select_db("info_book") or die("nottttt");

$book_name=null;
 $author_name=null;
$publisher_name=null;




$book_name=$_POST['bb1'];
 $author_name=$_POST['cc1'];
$publisher_name=$_POST['dd1'];
$name=null;
$booking_dates=null;
$delivered_dates=null;
$phone_nuns=0;
$Email_ids=null;
$f=null;




$dbbook=null;
$dban=null;
$dbpn=null;
$dbtb=null;
$dbco=null;
$name=$_SESSION['name'];
$sai=$_SESSION['booking_code'];

$phone_nuns=$_SESSION['phone_nun'];
$Email_ids=$_SESSION['Email_id'];
$f="processing";

if($book_name!=NULL && $author_name!=NULL && $publisher_name!=NULL)
{

	$query= mysql_query("SELECT *  FROM user_delivery WHERE publisher_na='$publisher_name' AND user_name='$name' AND book_na='$book_name' AND author_na='$author_name'  AND booking_id='$sai' AND phone_number='$phone_nuns' AND email_add='$Email_ids'  AND delivery_report='$f'")or die("not selected");
	

	while($row=mysql_fetch_assoc($query))
		{
			$dbbook= $row['book_na'];
			$dban=$row['author_na'];
			$dbpn=$row['publisher_na'];
			$dbtb=$row['total_books'];
			$dbco=$row['cost'];
                     		
		}
		if($book_name==$dbbook && $author_name==$dban && $publisher_name==$dbpn)
		{
	
$_SESSION['to']=$dbtb;
$_SESSION['cos']=$dbco;
$_SESSION['bb']=$dbbook;

$_SESSION['au']=$dban;


$_SESSION['pu']=$dbpn;
		}

else
{
?>
<script>
alert("book not available check and retry");
window.location.href="cancel1.php";
</script>
<?php
}



}
else
{
?>
<script>
alert("please enter details");
window.location.href="cancel1.php";
</script>
<?php
}

?>
<center>
	
<h3>   book name  : <?php echo $dbbook; ?> </h3>
<h3>   author name  : <?php echo $dban; ?> </h3>
<h3>   publisher name  : <?php echo $dbpn; ?> </h3>
<h3>   total books : <?php echo $dbtb; ?> </h3>
<h3>   single book cost  : <?php echo $dbco; ?> </h3>

<form action="cancel3.php" method="POST">
<input type="submit" class="btn_login" value="submit"> 
</form>

<form action="cancel1.php" method="POST">
<input type="submit" class="btn_login" value="Back"> 
</form>

</center>
</body>

</html>


