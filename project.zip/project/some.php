<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
 
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
	$query= mysql_query("SELECT * FROM books_selected")or die("not selected");
	
 
		
session_start();
$dbname='book';
$dbauthor='author';
$dbpublisher='publisher';
$dbcourse='type';
$dbcost='cost';
$dbtob='total_books';
$dbtoc='total_cost';
$dd=date("d");
$d=$dd+3;
$user=$_SESSION['user_name'];

	
$tt=$_SESSION['total'];	
while($rows = mysql_fetch_array($query))
		{
	        

               
	}

$a1=$_SESSION['user_na'];
$a2=$_SESSION['address'];
$a3=$_SESSION['city_na'];
$a4=$_SESSION['state_na'];
$a5=$_SESSION['mobile'];
$a6=$_SESSION['email_add'];


$query1234=mysql_query("SELECT * FROM user_delivery WHERE user_name='$a1' AND phone_number='$a5' AND 	email_add='$a6' AND city='$a3' AND state='$a4'")or die("not selected");
$dbbid;
while($row=mysql_fetch_assoc($query1234))
		{
			$dbbid= $row['booking_id'];
			
              	}
															
$aaa=$dbbid;								
							 ?>
    						
<br><br> <br><center><font size="06">	

 <font size="06">Total amount : <?php echo $tt; ?> </font><br><br>


<font size="06">Todays Date : <?php echo date("Y/m/d"); ?> </font><br><br>
<font size="06">Delivery  Date : <?php 

$da=date('Y-m-d');
echo date('Y-m-d', strtotime($da .'+3 day'))."<br>";
$de=date('Y-m-d', strtotime($da .'+3 day'));


$_SESSION['booked_date']=$da;
$_SESSION['delivered_date']=$de;

?> </font><br><br><br>
<font size="5" color="darkblack"> Message :<br></font> <br>
<font size="5" color="red"> Your Booking Is  Suceessfully Completed.  please Remember booking code</font><br>
<br><br>

<font size="6"> Thank You For Online BOOK SHOPPING :</font> <font size="10" color="blue"> <i><?php echo $user; ?> </i></font> <br>  

<font size="6"> YOUR Booking Code :</font> <font size="10" color="blue"> <i><?php echo $aaa; ?> </i></font> <br>


<br><br>
<form action="homepage.html">
<input type="submit" value="Ok"> 
</form><br>

</font></center>

</body>
</html> 