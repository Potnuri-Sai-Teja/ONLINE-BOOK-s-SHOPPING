<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php

	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
	$query= mysql_query("SELECT * FROM books_selected")or die("not selected");
	

$total;	

session_start();
$dbtoc='total_cost';
	

while($rows = mysql_fetch_array($query))
		{
	       $total=$total+ $rows[$dbtoc] ; 
		}
$_SESSION['total']=$total;
	header("location:printing.php");


?>
</body>
</html>
		
   

 				
						
										
								
							