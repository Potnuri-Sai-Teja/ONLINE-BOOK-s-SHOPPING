<?php
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");

mysql_select_db("info_book") or die("nottttt");
mysql_query("create table book_info_table(id int(4) AUTO_INCREMENT UNIQUE,book_name varchar(100),author_name varchar(30),publisher_name varchar(30),course varchar(100),img_path varchar(100),book_cost int(13),num_books int(12))");
mysql_query("ALTER TABLE `book_info_table` ADD `id` INT(4) NOT NULL AUTO_INCREMENT FIRST, ADD UNIQUE (`id`)");
$a=$_POST['bn'];
 $c=$_POST['an'];
$d=$_POST['pn'];
$e=$_POST['bc'];
$f=$_POST['img'];
$g=$_POST['bb'];
$z=$_POST['nob'];
$_SESSION['bo']=$a;
$_SESSION['ao']=$c;

if($a==NULL || $c==NULL || $d==NULL || $e==0 || $f==NULL || $g==NULL || $z==0 )
{ ?>
<script>
    
            alert("Enter your details ");
           window.location.href="adding_books.html";
            </script>
<?php
}
else 
{
mysql_query("INSERT INTO book_info_table VALUES(null,'$a','$c','$d','$g','$f',$e,$z) ") or die("not inserted");
echo " row is inserted";
header("location:adding_books.html");
}
?>


