<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>

<?php
 session_start();
	$x;
     
	$Author=$_SESSION['aname'];
	$Publisher=$_SESSION['pname'];
	$Name=$_SESSION['name'];
	$Course=$_SESSION['cou'];
	$Cost=$_SESSION['amount'];
$total_amount=$_SESSION['totala'];
$num_of_books=$_SESSION['selected'];		
?>

<table width="100%" border="0">
								<tr >
									<Td> <b>Book_name
									<td> <b>Author_name
									<td> <b>Publisher_name
									<td> <b>Group
									<td> <b>Amount
									<td> <b>Total books
									<td> <b>Total Amount
								</tr>
								<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
							<?php echo "
											<tr>
											<Td> $Name
											<td>$Author
											<td>$Publisher
											<td>$Course
											<td>$Cost
											<td>$num_of_books
											<td>$total_amount
											
										</tr>
										";
							 ?>
    						</table>
<br><br> <br><center><font size="06">	
<form action="search1233.html">
<input type="submit" value="Add Books">  
</form><br>
<form action="user_book.php">
<input type="submit" value="Add To Cart"> 
</form><br>
<form action="printing.php">
<input type="submit" value="CONTINUE"> 
</form>
</font></center>

</body>
</html> 