<html>
<head>
<title></title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
 
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
	$query= mysql_query("SELECT * FROM books_selected")or die("not selected");
	

	
?>
<table width="100%" border="0">
								<tr>
									<Td> <b>Book_name
									<td> <b>Author_name
									<td> <b>Publisher_name
									<td> <b>Group
									<td> <b>Amount
									<td> <b>Total books
									<td> <b>Total Amount
								</tr>
								<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
							<?php 
		
session_start();
$dbname='book';
$dbauthor='author';
$dbpublisher='publisher';
$dbcourse='type';
$dbcost='cost';
$dbtob='total_books';
$dbtoc='total_cost';
$dd=date("d");
$d=$dd+3;
$user=$_SESSION['user_name'];

	
$tt=$_SESSION['total'];	
while($rows = mysql_fetch_array($query))
		{
	        

echo "
 		   <br>
  		  <tr> 

	<td> $rows[$dbname] <br>  </td>
	<td> $rows[$dbauthor]   <br></td>
	<td> $rows[$dbpublisher]   <br></td>
	<td> $rows[$dbcourse]   <br></td>
	<td> $rows[$dbcost]   <br></td>
	<td> $rows[$dbtob]   <br></td>
	<td> $rows[$dbtoc]  <br></td>
		
    </tr> 

 ";
               
	}
						
										
								
							 ?>
    						</table>
<br><br> <br><center><font size="06">	

 <font size="06">Total amount : <?php echo $tt; ?> </font><br><br>


<font size="06">Todays Date : <?php echo date("Y/m/d"); ?> </font><br><br>
<font size="06">Delivery  Date : <?php 

$da=date('Y-m-d');
echo date('Y-m-d', strtotime($da .'+3 day'))."<br>";
$de=date('Y-m-d', strtotime($da .'+3 day'));


$_SESSION['booked_date']=$da;
$_SESSION['delivered_date']=$de;

?> </font><br><br><br>
<font size="5" color="darkblack"> Message :<br></font> <br>
<font size="5" color="red"> If You Return Back Any book 10RS penalty charge have to pay.Before Clicking OK Button Please Check ALL Data and Click OK button </font><br>
<br><br>

<font size="6"> Thank You For Online BOOK SHOPPING :</font> <font size="10" color="blue"> <i><?php echo $user; ?> </i></font> <br>  
<br><br>
<form action="homepage.php">
<input type="submit" value="Ok"> 
</form><br>
<form action="shopping_details.html">
<input type="submit" value="Back"> 
</form><br>


</font></center>

</body>
</html> 