<?php 
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
mysql_select_db("users") or die("nottttt");
mysql_query("create table user_information(id bigint(4) AUTO_INCREMENT UNIQUE,first_name varchar(20),last_name varchar(20),user_name varchar(20),password varchar(20),confirmpassword varchar(20),phone bigint(17),address varchar(100))");
echo "table created";
#ALTER TABLE `user_information` ADD `id` INT(4) NOT NULL AUTO_INCREMENT FIRST, ADD UNIQUE (`id`);
$a=$_POST['fnm'];
$c=$_POST['lnm'];
$d=$_POST['un'];
$e=$_POST['pw'];
$f=$_POST['cpw'];
$g=$_POST['phn'];
$h=$_POST['add'];

if($a!=NULL && $c!=NULL && $d!=NULL && $e!=NULL && $f!=NULL && $g!=0 && $h!=NULL)
{
	if($e==$f)
	{
 mysql_query("INSERT INTO user_information VALUES('$a','$c','$d','$e','$f',$g,'$h')") or die("120120");
echo " row is inserted";
header("location:cust_login.html");
	}
	else
	{
		?>
		<script>
		alert("Password and Confirm password must be same");
		window.location.href="cust_login.html";
		</script>
<?php
	}
}
else
	{
		?>
		<script>
		alert("Please Enter Details");
		window.location.href="cust_login.html";
		</script>
<?php
	}



?>
