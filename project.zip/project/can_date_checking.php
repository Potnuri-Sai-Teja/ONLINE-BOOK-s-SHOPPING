<?php
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
mysql_select_db("info_book") or die("nottttt");

$name=$_POST['n'];
$booking_code=$_POST['b'];
$phone_nun=$_POST['p'];
$Email_id=$_POST['e'];


$_SESSION['name']=$name;
$_SESSION['booking_code']=$booking_code;
$_SESSION['phone_nun']=$phone_nun;
$_SESSION['Email_id']=$Email_id;

$da;
$f="processing";
$dbbbs=null;
$query= mysql_query("SELECT *  FROM user_delivery WHERE  user_name='$name' AND phone_number='$phone_nun' AND booking_id='$booking_code' AND phone_number='$phone_nun' ") or die ("Select eruygfuyhda");
	
$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$dbname= $row['user_name'];
			$dbdates=$row['booking_id'];
			$dbdate=$row['datee'];
			$dbddt= $row['delivery_date'];
			$dbphn= $row['phone_number'];	
			$dbea= $row['email_add'];
			$dbbbs=$row['delivery_report'];
			$db1=$row['book_na'];
$db2=$row['author_na'];
$db3=$row['publisher_na'];

	
			                      		
		}
	}



echo $dbname."<br>".$dbdate."<br>".$dbddt."<br>".$dbphn."<br>".$dbea;

$_SESSION['ab1']=$db1;

$_SESSION['ab2']=$db2;

$_SESSION['ab3']=$db3;


echo $name."<br>".$booking_date."<br>".$delivered_date."<br>".$phone_nun."<br>".$Email_id;


if($name==NULL || $booking_code==-1  || $phone_nun==0 || $Email_id==NULL)
{
?>
<script>
alert("please enter all values");
window.location.href="cancellation_details.html";
</script>
<?php
}
else if($name==$dbname && $booking_code==$dbdates && $phone_nun==$dbphn && $Email_id==$dbea)
{
echo $dbbbs.$f;
if($dbbbs==$f)
{
if($name==$dbname && $booking_code==$dbdates && $phone_nun==$dbphn && $Email_id==$dbea)
{

$da=date('Y-m-d');
	
		if($da>=$dbdate && $da<$dbddt)
		{
			header("location:cancel_choice.html");
		}
		else
		{
			?>
			<script>
		alert("cancelation failed, cant cancel delivery day");
		window.location.href="choice.html";
		</script>
		<?php
		}

}
else
{
?>
<script>
alert("Data is not matched please check and re-enter ");
window.location.href="cancellation_details.html";
</script>
<?php

}

}
else
{
?>
<script>
alert("You cant cancel the book becaue(delivery date) ");
window.location.href="cancellation_details.html";
</script>
<?php

}
	
}
else
{
?>
<script>
alert("cant cancel the data please check the details and retry");
window.location.href="cancellation_details.html";
</script>
<?php

}

?>