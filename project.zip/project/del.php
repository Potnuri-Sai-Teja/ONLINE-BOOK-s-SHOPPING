<?php

session_start();
	$connect=mysql_connect("localhost","root","") or die("coudld connect to database 1");
	
	mysql_select_db("info_book") or die("couldn't find database 2");
$a;

$Id=implode(',',$_POST['ch']);
$a=$_SESSION['book_name'];
$b=$_SESSION['author_name'] ;
$c=$_SESSION['publisher_name'];
$d=$_SESSION['num'];

echo $Id;
mysql_query("delete from books_selected where id in($Id)")or die("cant delete");
header("location:printing.php");

	
?>
	