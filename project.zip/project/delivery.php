<html>
<head>
<title>ADDING BOOKS</title>
  <link rel="stylesheet" href="css/x.css">
  <link rel='stylesheet prefetch' href="css/y.css">
  <link rel='stylesheet prefetch' href="css/z.css">
  <link rel="stylesheet" href="css/aform.css">  
<link rel="stylesheet" type="text/css" href="css/stylemenu.css" />
<script type="text/javascript" src="js/jus.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1>ONLINE BOOKS</h1>
		</div>
		
	</div>
<br><br><br>
<?php
session_start();
$connect=mysql_connect("localhost","root","") or die("coudld connect to database");
	
	mysql_select_db("info_book") or die("couldn't find database");
mysql_query("create table user_delivery(user_name varchar(50),booking_id bigint(100),id int(4) AUTO_INCREMENT UNIQUE,book_na varchar(50),author_na varchar(50),publisher_na varchar(50),total_books int(100),cost int(13),book_total_cost int(13),total_cost int(10),datee varchar(50),delivery_date varchar(50),delivery_report varchar(15),city varchar(50),state varchar(50),address varchar(100),email_add varchar(75),phone_number bigint(12))");
echo "table created";

$a1=$_SESSION['user_na'];
$c1=$_SESSION['address'];
$e1=$_SESSION['city_na'];
$f1=$_SESSION['state_na'];
$g1=$_SESSION['mobile'];
$h1=$_SESSION['email_add'];
$da1=$_SESSION['booked_date'];
$de1=$_SESSION['delivered_date'];
$ttt=$_SESSION['total'];



$dbbb=array("");
$dbbk=array("");
$dbna=array("");
$dban=array("");
$dbpn=array("");
$dbcos=array("");
$dbttcos=array("");

$aa='total_books';
$bb='book';
$cc='author';
$dd='publisher';
$ee='num_books';
$cos='cost';
$totcos='total_cost';
$query1="";
$query="";
$totb="";
$c=0;
$query2= mysql_query("SELECT * FROM books_selected");



$i=0;

$query= mysql_query("SELECT * FROM books_selected") or die("soooooooo") ;

	
		while($rows=mysql_fetch_array($query))
		{

			$dbbb[$i]=$rows[$aa];
			$dbna[$i]=$rows[$bb];
			$dban[$i]=$rows[$cc];
			$dbpn[$i]=$rows[$dd];
			$dbcos[$i]=$rows[$cos];
			$dbttcos[$i]=$rows[$totcos];
			$i++;
		}
$query1234= mysql_query("SELECT * FROM user_delivery")or die("not selected");
$total=0;	

$teja=0;
$dbtoc='booking_id';
	

while($rows = mysql_fetch_array($query1234))
		{
	       $total=$total+ $rows[$dbtoc] ; 
		
		}




for($i=0;$i<sizeof($dbbb);$i++)
{
$del="processing";
$teja=$total;
$teja=$teja+1;
echo $teja;
mysql_query("INSERT INTO user_delivery VALUES('$a1',$teja,null,'$dbna[$i]','$dban[$i]','$dbpn[$i]',$dbbb[$i],$dbcos[$i],$dbttcos[$i],$ttt,'$da1','$de1','$del','$e1','$f1','$c1','$h1',$g1)") or die("120120");
echo " row is inserted";
$ttt=0;
}

mysql_query("TRUNCATE TABLE books_selected");
header("location:thank.php");

?>
</body>
</html>