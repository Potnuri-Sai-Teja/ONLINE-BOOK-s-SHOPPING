<?php
session_start();
$b=mysql_connect("localhost","root","") or die("ksajdflk");
echo "connected";
mysql_select_db("info_book") or die("nottttt");

$aa=$_POST['uanm'];
 $cc=$_POST['ubnm'];
$dd=$_POST['unb'];
$ee;
$dbbook;
$query= mysql_query("SELECT *  FROM book_info_table WHERE book_name='$cc' AND author_name='$aa' ") or die ("Select eruygfuyhda");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
			$dbbook= $row['num_books'];
			$dbbna= $row['book_name'];
			$dbban= $row['author_name'];	
			$dbbpn= $row['publisher_name'];					                      		
		}
	}
if($aa==NULL || $cc==NULL || $dd==0)
{
?><script>
alert("enter values");
    window.location.href="update.html";

                </script>
<?php
}
else
{
if($cc==$dbbna && $aa==$dbban)
{
$ee=$dbbook + $dd;
mysql_query("UPDATE book_info_table SET num_books='$ee' WHERE book_name='$cc' AND author_name='$aa' ") or die("not updated");

header("location:adding_books.html");
}
else
{
?><script>
alert("Book not matched");
    window.location.href="update.html";

                </script>
<?php

}	
}
?>